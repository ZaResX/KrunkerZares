  //Misc
  document.title = "Krunker Social Page";
  //StyleSheets
  var socialFont = Array.from(document.styleSheets[0].cssRules).findIndex(rule => rule.selectorText === "*");
  document.styleSheets[0].cssRules[socialFont].style.fontFamily = "Arial Black";
  document.styleSheets[0].cssRules[socialFont].style.fontSize = "26px";
  var profileKR = Array.from(document.styleSheets[0].cssRules).findIndex(rule => rule.selectorText === "#profileKR");
  document.styleSheets[0].cssRules[profileKR].style.fontSize = "24px";
  var tourneyPNames = Array.from(document.styleSheets[0].cssRules).findIndex(rule => rule.selectorText === ".tourneyPNames");
  document.styleSheets[0].cssRules[tourneyPNames].style.fontSize = "15px";
  var tourneyName = Array.from(document.styleSheets[0].cssRules).findIndex(rule => rule.selectorText === ".tourneyName");
  document.styleSheets[0].cssRules[tourneyName].style.fontSize = "15px";
  var tourneyDate = Array.from(document.styleSheets[0].cssRules).findIndex(rule => rule.selectorText === ".tourneyDate");
  document.styleSheets[0].cssRules[tourneyDate].style.fontSize = "15px";
  var tourneyRegion = Array.from(document.styleSheets[0].cssRules).findIndex(rule => rule.selectorText === ".tourneyRegion");
  document.styleSheets[0].cssRules[tourneyRegion].style.height = "30px";
