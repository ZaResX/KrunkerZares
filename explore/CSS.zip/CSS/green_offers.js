var elementToObserve = document.getElementById("marketList");
var observer = new MutationObserver(function (mutation) {
    var offerDiv = document.getElementById("offers");
    if (offerDiv != null) {
        var offers = [...offerDiv.children[1].children];
        offers.shift();
        offers.forEach(element => {
            if (element.children[0].children[5].children[5].currentSrc == null) {
                document.getElementById(element.id).style.backgroundColor = "rgba(63, 255, 0, 0.71)";
            }
        });
    }
});
observer.observe(elementToObserve, { subtree: true, childList: true });